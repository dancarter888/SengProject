public class PlanetStartPlanet extends Planet{
    PlanetStartPlanet() {
        super("Pluto");
    }
}
