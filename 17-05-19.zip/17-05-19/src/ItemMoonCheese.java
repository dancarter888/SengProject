public class ItemMoonCheese extends FoodItem {

    public ItemMoonCheese() {
        super(20, "Moon Cheese", 25);
    }
}
