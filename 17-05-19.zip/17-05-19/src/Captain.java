public class Captain extends CrewMember{

    public Captain(String name) {
        super(50, "Bad", name, "Captain");
    }
}