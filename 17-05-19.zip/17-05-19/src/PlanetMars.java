public class PlanetMars extends Planet{
	PlanetMars() {
        super("Mars");
    }
}