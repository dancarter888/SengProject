public class PlanetMercury extends Planet{
	PlanetMercury() {
        super("Mercury");
    }
}