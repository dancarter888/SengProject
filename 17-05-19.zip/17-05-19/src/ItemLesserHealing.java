public class ItemLesserHealing extends MedicalItem {

    public ItemLesserHealing() {
        super(30, "Lesser Healing", 20);
    }
}
