import java.util.ArrayList;
import java.util.Scanner;

public class Crew {

    private String name;
    private int crewSize;
    private ArrayList<CrewMember> crewMemberList = new ArrayList<>();
    private ArrayList<Item> ownedItems = new ArrayList<>();
    private ArrayList<CrewMember> crewWithActionsRemaining = new ArrayList<>();
    private ArrayList<CrewMember> crewWithSpacePlague = new ArrayList<>();
    private int money = 100;
    private Ship theShip;
    private int piecesFound = 0;

    public Crew(int numberOfCrew, String name, String shipName) {
        this.name = name;
        this.crewSize = numberOfCrew;
        this.theShip = new Ship(shipName);

        //test item
        ItemApple apple = new ItemApple();
        ownedItems.add(apple);
        ItemSpacePlagueCure cure = new ItemSpacePlagueCure();
        ownedItems.add(cure);
        ItemLesserHealing lesser = new ItemLesserHealing();
        ownedItems.add(lesser);
        ownedItems.add(cure);
        ownedItems.add(lesser);
        ownedItems.add(cure);
        ownedItems.add(apple);
        ownedItems.add(cure);
        ownedItems.add(lesser);
    }

    public void createCrewMember(int classSelected, String name) {
    	
    	switch (classSelected) {
        case 1:
            Captain newCaptain = new Captain(name);
            System.out.println("Added Captain " + newCaptain.getName());
            this.crewMemberList.add(newCaptain);
            this.crewWithActionsRemaining.add(newCaptain);
            break;
        case 2:
            Engineer newEngineer = new Engineer(name);
            System.out.println("Added Engineer "  + newEngineer.getName());
            this.crewMemberList.add(newEngineer);
            this.crewWithActionsRemaining.add(newEngineer);
            break;
        default:
            break;
    }
    	
    	
    }

    public void updateCrewWithActionsRemaining() {
        ArrayList<CrewMember> actionsRemaining = new ArrayList<>();

        for(CrewMember crewMember : this.crewWithActionsRemaining) {
            if(crewMember.getActionsRemaining() > 0) {
                actionsRemaining.add(crewMember);
            }
        }

        this.crewWithActionsRemaining = actionsRemaining;
    }

    public boolean crewWithActions() {
        return this.crewWithActionsRemaining.size() > 0;
    }

    public void resetCrewActions() {
        for(CrewMember member : this.crewMemberList) {
            member.setActionsRemaining(2);
        }
        this.crewWithActionsRemaining = (ArrayList<CrewMember>) this.crewMemberList.clone();
        System.out.println("\nCrew members now have 2 actions remaining\n");
    }

    public String getShipStatus() {
        return this.theShip.toString();
    }

    public ArrayList<String> useItem(CrewMember member, String inItem) {
    	ArrayList<String> strings = new ArrayList<>();
    	
        if(this.ownedItems.size() > 0) {
            int indexOfItem = this.chooseItem(inItem);
            if(indexOfItem >=0 ) {
            	Item item = this.ownedItems.get(indexOfItem);
            	strings.add(item.useItem(member));
            	member.performAction();
            	this.ownedItems.remove(item); // could possibly remove in chooseItem()
            } else {
            	strings.add("You do not have that item");
            }
        } else {
            strings.add("You have no items!");
        }
        
        return strings;
    }

    public int chooseItem(String item) {
    	//"Apple", "LesserHealing", "PlagueCure"
    	int itemToUse = -1;
    	switch(item) {
    		case "Apple":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemApple) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Moon Cheese":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemMoonCheese) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Spaceghetti":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemSpaceghetti) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Lesser Healing":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemLesserHealing) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Greater Healing":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemGreaterHealing) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Plague Cure":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemSpacePlagueCure) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		default:
    			break;
    		
    	}
//        Scanner scanner = new Scanner(System.in);
//        String items = "Which Item To Use? \n";
//        for (int i = 1; i < this.ownedItems.size() + 1; i++) {
//            items += String.format("%d. %s\n", i, this.ownedItems.get(i - 1).getName());
//        }
//        System.out.println(items);
//        int index = scanner.nextInt();

        //scanner.close();
        return itemToUse;
    }

    public ArrayList<String> dealSpacePlagueDamage() {
        // updates the sapce plague list
    	ArrayList<String> strings = new ArrayList<>();
        this.updateCrewWithSpacePlague(); // where to do this
        // deals the damage for the space plague
        ArrayList<CrewMember> sickMembers = (ArrayList<CrewMember>) this.crewWithSpacePlague.clone();
        for(CrewMember member : sickMembers) {
            strings.add(member.spacePlagueDamage());
            if(member.getHealth() <= 0) {
                strings.add(String.format("%s has died...", member.getName()));
                this.crewMemberList.remove(member);
                this.crewWithSpacePlague.remove(member);
                this.crewSize--;
            }
        }
        
        return strings;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCrewSize() {
        return crewSize;
    }

    public void setCrewSize(int crewSize) {
        this.crewSize = crewSize;
    }

    public ArrayList<CrewMember> getCrewMemberList() {
        return crewMemberList;
    }

    public void setCrewMemberList(ArrayList<CrewMember> crewMemberList) {
        this.crewMemberList = crewMemberList;
    }

    public ArrayList<Item> getOwnedItems() {
        return ownedItems;
    }

    public void addOwnedItems(Item item) {
        this.ownedItems.add(item);
    }

    public void removeOwnedItems(int indexRemoved) {
        this.ownedItems.remove(indexRemoved);
    }

    public void setOwnedItems(ArrayList<Item> ownedItems) {
        this.ownedItems = ownedItems;
    }


    public ArrayList<CrewMember> getCrewWithActionsRemaining() {
        return crewWithActionsRemaining;
    }

    public void setCrewWithActionsRemaining(ArrayList<CrewMember> crewWithActionsRemaining) {
        this.crewWithActionsRemaining = crewWithActionsRemaining;
    }

    public ArrayList<CrewMember> getCrewWithSpacePlague() {
        return crewWithSpacePlague;
    }

    public void updateCrewWithSpacePlague() {
        for(CrewMember member : this.crewMemberList) { // not sure if you can use crewwithspaceplague for this
            if(this.crewWithSpacePlague.contains(member) && !member.getHasPlague()) {
                this.crewWithSpacePlague.remove(member);
            }
        }
    }

    public void addCrewWithSpacePlague(CrewMember member) {
        if(!(this.crewWithSpacePlague.contains(member))) {
            this.crewWithSpacePlague.add(member);
        } else {
            System.out.println("They are allreeady infected");
        }
    }

    public void setCrewWithSpacePlague(ArrayList<CrewMember> crewWithSpacePlague) {
        this.crewWithSpacePlague = crewWithSpacePlague;
    }

    public int getMoney() {
        return money;
    }

    public void addMoney(int amount) {
        this.money += amount;
    }

    public void removeMoney(int amount) {
        this.money -= amount;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public Ship getTheShip() {
        return theShip;
    }

    public void setTheShip(Ship theShip) {
        this.theShip = theShip;
    }

    public int getPiecesFound() {
        return piecesFound;
    }

    public void addPiecesFound() {
        this.piecesFound++;
    }

    public void printCrew() {
        String printString = "Crew named " + name + ":\n";
        int i = 0;
            for (CrewMember member : crewMemberList) {
                i ++;
                printString += i + ". ";
                printString += member.toString();
                printString += "\n";
            }
        System.out.println(printString);
    }


}
