public class PlanetVenus extends Planet{
	PlanetVenus() {
        super("Venus");
    }
}