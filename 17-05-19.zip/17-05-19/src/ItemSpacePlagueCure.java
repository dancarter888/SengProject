public class ItemSpacePlagueCure extends MedicalItem {

    public ItemSpacePlagueCure() {
        super(50, "Plague Cure", 0);
    }
}
