public class ItemSpaceghetti extends FoodItem {

    public ItemSpaceghetti() {
        super(50, "Spaceghetti", 80);
    }
}
