public class ItemApple extends FoodItem {

    public ItemApple() {
        super(10, "Apple", 10);
    }
}
