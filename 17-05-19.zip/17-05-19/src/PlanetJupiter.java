public class PlanetJupiter extends Planet{
	PlanetJupiter() {
        super("Jupiter");
    }
}