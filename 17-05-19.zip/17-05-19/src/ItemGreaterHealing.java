public class ItemGreaterHealing extends MedicalItem {

    public ItemGreaterHealing() {
        super(65, "Greater Healing", 80);
    }
}
