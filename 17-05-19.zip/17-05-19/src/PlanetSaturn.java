public class PlanetSaturn extends Planet{
	PlanetSaturn() {
        super("Saturn");
    }
}