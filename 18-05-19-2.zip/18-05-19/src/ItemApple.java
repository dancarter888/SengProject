/**
 * This class implements the apple item for the game.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class ItemApple extends FoodItem {
	/**
	 * Initializes the class and calls the super of parent class FoodItem
	 * with the cost, name, and hunger restored of the item
	 */
    public ItemApple() {
        super(10, "Apple", 10);
    }
}
