import java.util.ArrayList;
import java.util.Random;

/**
 * This class implements the planet class for the game.
 * It is used to handle instances of planet.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class Planet {

	/**
	 * The name of the planet
	 */
    String name;
    /**
     * Whether the part is found for the planet
     */
    private boolean partFound = false;
    /**
     * List of all the items on the planet
     */
    private ArrayList<Item> itemsOnPlanet = new ArrayList<>();
    /**
     * List of all items in game
     */
    private ArrayList<Item> allItems;
    /**
     * The outpost for the planet
     */
    private OutPost outPost = new OutPost();

    /**
     * Sets the initial values for the planet name, and creates
     * the list of items for the planet.
     * 
     * @param name		Sting name of the planet
     */
    public Planet(String name) {
        this.name = name;
        this.allItems = GameEnvironment.allItems;
        generateItems();
    }

    /**
     * Generates the items for the planet.
     */
    public void generateItems() { // This needs to randomise
        System.out.println("Generating Items For " +  this.name + "...");
        for (Item item : this.allItems) {
            itemsOnPlanet.add(item);
            System.out.println(item + "\n");
        }
    }

    /**
     * Given crew member searches the planet
     * 
     * @param crew		Crew the crew
     * @param member	CrewMember the member player wants to search the planet
     * @return strings  ArrayList<String> of the dialogue from using the item
     */
    public ArrayList<String> searchPlanet(Crew crew, CrewMember member) {
        // Change when get items working
        //returns item
    	ArrayList<String> strings = new ArrayList<>();
        Random rand = new Random();
        int randomNumber = rand.nextInt(6);
        while (partFound == true && randomNumber == 4) {
            randomNumber = rand.nextInt(5);
        }
        strings.add(member.getName() + " is searching planet " + name + "...");
        switch (randomNumber) {
            case 0:
            case 1:
            case 2://Item Found
                strings.add("Item Found: " + allItems.get(randomNumber).getName());
                crew.addOwnedItems(allItems.get(randomNumber));
                break;
            case 3://Money Found
                strings.add(findMoney(crew));
                break;
            case 4://Part Found
                partFound = true; // Could use observer
                crew.addPiecesFound();
                strings.add("Transporter Found");
                break;
            case 5://Nothing Found
                strings.add("Nothing found");
                break;
            default:
                System.out.println("No actions");
                break;
        }
        
        return strings;
    }

    /**
     * If money found on planet method returns the amount found
     * 
     * @param crew		Crew the crew
     * @return found 	String of the amount of money found
     */
    public String findMoney(Crew crew) {
        Random rand = new Random();
        String found = "";
        int randomMoney = rand.nextInt(3);
        switch (randomMoney) {
            case 0:
                found = addMoney(crew, 25);
                break;
            case 1:
            	found = addMoney(crew, 50);
                break;
            case 2:
            	found = addMoney(crew, 75);
                break;
            case 3:
            	found = addMoney(crew, 100);
                break;
        }
        
        return found;
    }

    /**
     * Adds money to the crew
     * 
     * @param crew		Crew the crew
     * @param amount	int the amount of money to add
     * @return string 	String of the amount of money added/found
     */
    public String addMoney(Crew crew, int amount) {
        crew.addMoney(amount);
        return("$" + amount + " Found! You now have $" + crew.getMoney());
    }
    
    /**
     * Gets partfound
     * 
     * @return boolean partFound
     */
    public boolean getPartFound() {
        return partFound;
    }

    /**
     * Sets part found
     * 
     * @param partFound whether part has been found
     */
    public void setPartFound(boolean partFound) {
        this.partFound = partFound;
    }

    /**
     * Gets items on planet
     * 
     * @return itemsOnPlanet ArrayList<String> of the item on planet
     */
    public ArrayList<Item> getItemsOnPlanet() {
        return itemsOnPlanet;
    }

    public void setItemsOnPlanet(ArrayList<Item> itemsOnPlanet) {
        this.itemsOnPlanet = itemsOnPlanet;
    }

    /**
     * Gets the name of planet
     * 
     * @return name String name of planet
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the planet
     * 
     * @param name String name of the palnet
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets outpost of the planet
     * 
     * @return outPost OutPost the outpost
     */
    public OutPost getOutPost() {
        return this.outPost;
    }

    /**
     * Returns string describing planet
     * 
     * @return string String describes planet
     */
    public String toString() {
        String returnString = this.name;
        return returnString;
    }
}