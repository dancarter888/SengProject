import java.util.ArrayList;

/**
 * This class implements the ship for the game.
 * It is used to handle the ship and everything associated with the ship,
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class Ship {

	/**
	 * The name of the ship.
	 */
    private String name;
    /**
     * The shields of the ship.
     */
    private int shields = 100;
    /**
     * The planet which the ship is currently at.
     */
    private Planet location;
    /**
     * A list of all the planets.
     */
    private ArrayList<Planet> allPlanets = new ArrayList<>();

    /**
     * Sets the initial values of the ship name, and location.
     * 
     * @param name		string name of the ship
     */
    public Ship(String name) {
        this.name = name;
        this.location = new PlanetStartPlanet();
        setAllPlanets();
    }

    /**
     * Sets the instance variable allPlanets to the list of all planets
     */
    public void setAllPlanets() {
    	this.allPlanets = GameEnvironment.allPlanets;
    }

    /**
     * Gets the name of the ship
     * 
     * @return name string name of the ship
     */
    public String getName() {
        return name;
    }

    /**
     * Repairs the shields of the ship
     * 
     * @param member	CrewMember member you player wants to repair shields
     * @return strings 	ArrayList<String> of the dialogue from using the item
     */
    public ArrayList<String> repairShields(CrewMember member) {
        // maybe different amount depending on class
        if((this.shields + 20) >= 100) {
            this.shields = 100;
        } else {
            this.shields += 20;
        }
        
        ArrayList<String> strings = new ArrayList<>();
        strings.add(String.format("%s repairing shields...", member.getName()));
        strings.add(String.format("Ship now has %d shields", this.shields));
        member.performAction();
        
        return strings;
    }

    /**
     * Calls the search planet method of the current location
     * 
     * @param crew		Crew the players crew
     * @param member	CrewMember The member the player wants to perform action
     * @return strings	ArrayList<String> of the dialogue from using the item
     */
    public ArrayList<String> searchThePlanet(Crew crew, CrewMember member) {
        ArrayList<String> strings = this.location.searchPlanet(crew, member);
        member.performAction();
        return strings;
    }
// ###########################################################################################################################################
    
    /**
     * Travels to the planet select by the player
     * 
     * @param memberOne		CewMember first member to pilot ship
     * @param memberTwo		CrewMember second member to pilot ship
     * @param planet		String the name of the planet player wants to travel to
     * @return strings		ArrayList<String> of the dialogue from using the item
     */
    public ArrayList<String> travelToNewPlanet(CrewMember memberOne, CrewMember memberTwo, String planet) {
    	ArrayList<String> strings = new ArrayList<>();
        Planet newPlanet = this.choosePlanet(planet);
        this.location = newPlanet;
        strings.add(Events.asteroidBelt(this));
        strings.add(memberOne.getName() + " and " + memberTwo.getName() + " have piloted ship to " + this.location.getName());
        
        return strings;
    }
    
    /**
     * Deals damage to the shields of the ship
     */
    public void damageShields() {
    	this.shields -= 20;
    }
    
    /**
     * Returns the planet depending on the given name
     * 
     * @param planet			string name of the planet
     * @return planetObject		Planet object of the name given
     */
    public Planet choosePlanet(String planet) {
        int index = -1;
        switch(planet) {
        	case "Pluto":
        		index = 0;
    		break;
        	case "Mercury":
        		index = 1;
        		break;
        	case "Venus":
        		index = 2;
        		break;
        	case "Mars":
        		index = 3;
        		break;
        	case "Jupiter":
        		index = 4;
        		break;
        	case "Saturn":
        		index = 5;
        		break;
        	default:
        		break;
        }       		

        //scanner.close();
        return this.allPlanets.get(index);
    }

    /**
     * Gets shields
     * 
     * @return shields int the current shields
     */
    public int getShields() {
        return shields;
    }

    /**
     * Sets the shield
     * 
     * @param shields int what you want to set the shields to
     */
    public void setShields(int shields) {
        this.shields = shields;
    }

    /**
     * Gets the current location
     * 
     * @return planet Planet current location
     */
    public Planet getLocation() {
        return location;
    }

    /**
     * Sets the location
     * 
     * @param location Planet location to set
     */
    public void setLocation(Planet location) {
        this.location = location;
    }

    /**
     * Returns string describing ship
     * 
     * @return string String describes ship
     */
    public String toString() {
        return String.format("Name: %s\nShields: %d\nLocation: %s", this.name, this.shields, this.location); // need location string not just the object
    }


}
