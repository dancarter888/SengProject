/**
 * Interface class for Item, for usable items
 * 
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public interface Item {

	/**
	 * Returns the cost of an item
	 * @return cost 	int the cost of the item
	 */
    int getCost();
    /**
     * Gets the name of an item
     * 
     * @return name 	String the name of the item
     */
    String getName();
    /**
     * Gets the description of an item
     * 
     * @return description 		String the description of the item
     */
    String getDescription();
    /**
     * Uses the item on the crew member passed in as the parameter
     * 
     * @param member		CrewMember the member the player wants use the item on
     * @return string 		String the dialogue of using the item
     */
    String useItem(CrewMember member);
    /**
     * Returns string describing item
     * 
     * @return string String describes item
     */
    String toString();
}
