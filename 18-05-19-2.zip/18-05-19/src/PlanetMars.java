/**
 * This class implements the planet Mars for the game.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class PlanetMars extends Planet{
	/**
	 * Initializes the class and calls the super of parent class planet
	 * with the name of the planet
	 */
	PlanetMars() {
        super("Mars");
    }
}