public class Engineer extends CrewMember{

    public Engineer(String name) {
        super(20, "Good", name, "Engineer");
    }
}