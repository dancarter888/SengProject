
import java.util.ArrayList;
import java.util.Random;

/**
 * This class implements the game environment for the game.
 * It is used to handle the gui and the states between the gui's,
 * also helps the gui's for calling different parts of the game
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class GameEnvironment {

    /**
     * The total number of days to be played.
     */
    private int totalDays;
    /**
     * The current game in the game.
     */
    private int currentDay = 1;
    /**
     * The number of spaceship pieces needed to
     * win the game.
     */
    private int piecesNeeded;
    /**
     * The number of crew members for the game.
     */
    private int numberOfCrew;
    /**
     * An instance of class crew which contains the crew
     * for the game.
     */
    private Crew crew;
    /**
     * A final static variable that stores all the items
     * in the game.
     */
    public static final ArrayList<Item> allItems = getAllItems();
    /**
     * A final static variable that stores all the planets
     * in the game
     */
    public static final ArrayList<Planet> allPlanets = getAllIPlanets();
    /**
     * The name of the crew
     */
    private String crewName;
    /**
     * The name of the ship
     */
    private String shipName;

    /**
     * Sets the initial values for totalDays, piecesNeeded, numberOfCrew given
     * by the parameters.
     *
     * @param totalDays     int of the total number of days
     * @param piecesNeeded  int of the number of pieces needed
     * @param numberOfCrew  int of the number of crew wanted
     * @param name
     */
    public GameEnvironment(int totalDays, int piecesNeeded, int numberOfCrew, String name) {
        this.totalDays = totalDays;
        this.piecesNeeded = piecesNeeded;
        this.numberOfCrew = numberOfCrew;
        //this.crew = new Crew(numberOfCrew, name);
    }

    /**
     * A static method that returns an array list of all the
     * items in the game, the items are of type Item.
     *
     * @return items    ArrayList<Item> list of all items in game.
     */
    public static ArrayList<Item> getAllItems() {
        ItemApple apple = new ItemApple();
        ItemMoonCheese cheese = new ItemMoonCheese();
        ItemSpaceghetti spaceghetti = new ItemSpaceghetti();
        ItemSpacePlagueCure cure = new ItemSpacePlagueCure();
        ItemLesserHealing lesser = new ItemLesserHealing();
        ItemGreaterHealing greater = new ItemGreaterHealing();

        ArrayList<Item> items = new ArrayList<>();
        items.add(apple);
        items.add(cheese);
        items.add(spaceghetti);
        items.add(cure);
        items.add(lesser);
        items.add(greater);

        return items;
    }

    /**
     * A static method that returns an array list of all the
     * planets in the game, the planets are of type Planet.
     *
     * @return planets    ArrayList<Planet> list of all planets in game.
     */
    public static ArrayList<Planet> getAllIPlanets() {
        Planet startPlanet = new PlanetStartPlanet();
        Planet mercury = new PlanetMercury();
        Planet venus = new PlanetVenus();
        Planet mars = new PlanetMars();
        Planet jupiter = new PlanetJupiter();
        Planet saturn = new PlanetSaturn();

        ArrayList<Planet> planets = new ArrayList<>();
        planets.add(startPlanet);
        planets.add(mercury);
        planets.add(venus);
        planets.add(mars);
        planets.add(jupiter);
        planets.add(saturn);
        System.out.println("Planets" + planets + "\n");

        return planets;
    }

    /**
     * Creates a new instance of GameScreen, which launches
     * the GameScreen gui.
     */
    public void launchGameGui() {
        GameScreen gameGui = new GameScreen(this);
    }

    /**
     * Closes the instance of the GameScreen screen mainWindow
     *
     * @param mainWindow    The current instance of the GameScreen gui.
     */
    public void closeGameGui(GameScreen mainWindow) {
        mainWindow.closeWindow();
    }

    /**
     * Creates a new instance of GameSetup, which launches
     * the GameSetup gui.
     */
    public void launchSetupGui() {
        GameSetup setupWindow = new GameSetup(this);
    }

    /**
     * Closes the instance of the setup gui screen setupWindow.
     *
     * @param setupWindow    The current instance of the GameScreen gui.
     */
    public void closeSetupGui(GameSetup setupWindow) {
        setupWindow.closeWindow();
        launchCreateCrewMembersGui();
    }

    /**
     * Creates a new instance of CreateCrewMemberGui, which launches
     * the CreateCrewMember gui.
     */
    public void launchCreateCrewMembersGui() {
        CreateCrewMembers createGui = new CreateCrewMembers(this);
    }

    /**
     * Closes the instance of the create crew member screen createGui.
     *
     * @param createGui    The current instance of the CreateCrewMembers gui.
     */
    public void closeCreateCrewMembersGui(CreateCrewMembers createGui) {
        createGui.closeWindow();
        launchGameGui();
    }

    /**
     * Closes the current GameScreen gui.
     * Creates a new instance of PilotShipGui, which launches
     * the PilotShipGui gui.
     */
    public void launchPilotShipGui(GameScreen gameGui) {
        gameGui.closeWindow();
        PilotShipScreen pilotGui = new PilotShipScreen(this);
    }

    /**
     * Closes the instance of the PilotShipGui screen .
     * Relaunches the GameScreenGui
     *
     * @param pilotGui   The current instance of the PilotShipScreen gui.
     */
    public void closePilotShipGui(PilotShipScreen pilotGui) {
        pilotGui.closeWindow();
        launchGameGui();
    }

    /**
     * Closes the current GameScreen gui.
     * Creates a new instance of OutPostGui, which launches
     * the outpost gui.
     */
    public void launchOutPostGui(GameScreen gameGui) {
        gameGui.closeWindow();
        OutPost outpost = this.crew.getTheShip().getLocation().getOutPost();
        OutPostGui outPostGui = new OutPostGui(this, outpost, this.crew);
    }

    /**
     * Closes the instance of the OutPOstGui screen .
     * Relaunches the GameScreenGui
     *
     * @param outPostGui   The current instance of the OutPostGui gui.
     */
    public void closeOutPostGui(OutPostGui outPostGui) {
        outPostGui.closeWindow();
        launchGameGui();
    }

    /**
     * Creates a new instance of Crew with the given parameters and
     * sets the instance variable crew to this instance of Crew.
     *
     * @param numberOfCrew  int of the size of the crew
     * @param crewName      string of the name of the crew
     * @param shipName      string of the name of the ship
     */
    public void createCrew(int numberOfCrew, String crewName, String shipName) {
        this.crew = new Crew(numberOfCrew, crewName, shipName);
    }

    // Just for gui ###############
    public void setTotalDays(int days) {
        totalDays = days;
    }

    public void setPiecesNeeded(int num) {
        piecesNeeded = num;
    }

    public void setNumberOfCrew(int num) {
        numberOfCrew = num;
    }

    public void setCrewName(String name) {
        this.crewName = name;
    }

    public void setShipName(String name) {
        this.shipName = name;
    }

    // ############################
    public int getTotalDays() {
        return totalDays;
    }

    public int getCurrentDay() {
        return currentDay;
    }

    public int getPiecesNeeded() {
        return piecesNeeded;
    }

    public int getNumberOfCrew() {
        return numberOfCrew;
    }

    public String getCrewName() {
        return this.crewName;
    }

    public String getShipName() {
        return this.shipName;
    }

    public Crew getCrew() {
        return crew;
    }

    /**
     * Calls an action according to the parameter actions.
     *
     * @param actions   int the action which player wants to do.
     * @param member    CrewMember, the member which player wants to perform action.
     * @return strings  ArrayList<String> of the dialogue from the action.
     */
    public ArrayList<String> takeAction(int actions, CrewMember member) {
        ArrayList<String> strings = new ArrayList<>(); //place holder
        if(member.getActionsRemaining() == 0) {
            strings.add("This crew member has no actions remaining!");
        } else if(member.getTiredness() == 0 && actions != 2) {
            strings.add("This crew member has no energy left!");
        } else if(member.getHunger() < 20) {
            strings.add("This crew member needs to eat!");
        } else {
            switch (actions) {
                case 1:
                    //consumeItem
                    //create method in crew use item where can choose which item and which member to use it on, eat/takeMedicine method in crew member
                    //Actions.useItem(this.crew, member);
                    break;
                case 2:
                    // sleep
                    // Choose crew member here and create method in crewMember
                    strings = Actions.sleep(member);
                    break;
                case 3:
                    //repair
                    // create method in ship
                    strings = Actions.repairShip(this.crew, member);
                    break;
                case 4:
                    //search planet
                    // get planet and use search method
                    strings = Actions.searchPlanet(this.crew, member);
                    break;
                case 5:
                    //Pilot Ship
                    //Actions.pilotShip(this.crew);
                    break;
                default:
                    System.out.println("No actions");
                    break;
            }
            this.crew.updateCrewWithActionsRemaining();
        }

        return strings;
    }

    /**
     * Called when need to move to next day, resets crew actions,
     * deals space plague damage, calls a random event.
     *
     * @return strings  ArrayList<String> of the dialogue from the action.
     */
    public ArrayList<String> newDay() {
        this.currentDay++;
        // create method in crew with for loop to reset all actionsRemaining
        this.crew.resetCrewActions();
        //check for space plague
        ArrayList<String> strings = this.crew.dealSpacePlagueDamage();
        this.numberOfCrew = this.crew.getCrewSize();
        //random event
        Random rand = new Random();
        int randEvent = rand.nextInt(2);
        strings.add(this.callEvent(randEvent));
        strings.add(String.format("Current day: %d", this.currentDay));

        return strings;
    }

    /**
     * Calls an event according to the parameter event.
     *
     * @param event     int the event which is to be called.
     * @return text     string of the dialogue of event.
     */
    public String callEvent(int event) {
        //System.out.println("\nEvent called");
        String text = "";
        switch (event) {
            case 0:
                text = Events.alienPirates(this.crew);
                break;
            case 1:
                if (this.crew.getCrewMemberList().size() > this.crew.getCrewWithSpacePlague().size()) {
                    text = Events.spacePlague(this.crew);
                }
                else {
                    text = Events.alienPirates(this.crew);
                }
                break;
        }

        return text;
    }

    public static void main(String[] args) {
        GameEnvironment game = new GameEnvironment(0, 0, 0, "hello");
        game.launchSetupGui();
    }
}