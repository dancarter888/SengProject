/**
 * This class implements the food item class for the game.
 * It is used to handle the stuff to do with the food items,
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class FoodItem implements Item {

	/**
	 * Cost of the item
	 */
    int cost;
    /**
     * Name of the item
     */
    String name;
    /**
     * The amount of hunger restored by item
     */
    int hungerRestored;

    /**
     * Sets the initial values of the item cost, name, and hunger restored
     * 
     * @param cost		int cost of the item
     * @param name		String name of the item
     * @param hungerRestored	int hunger restored by item
     */
    public FoodItem(int cost, String name, int hungerRestored) {
        this.cost = cost;
        this.name = name;
        this.hungerRestored = hungerRestored;
    }

    /**
     * Gets the cost of the item
     */
    @Override
    public int getCost() {
        return cost;
    }

    /**
     * Gets the name of the item
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * Gets the description of the item
     * 
     * @return description String of the description of the item
     */
    @Override
    public String getDescription() {
        return String.format("Restores %d hunger", hungerRestored);
    }

    /**
     * Uses the item on a member
     * 
     * @param member 	CrewMember the member player wants to use the item on
     * @return text		String of the dialogue from using the item
     */
    @Override
    public String useItem(CrewMember member) {
        String text = member.increaseHunger(hungerRestored);
        text = String.format("%s item used...\n", name) + text;
        return text;
    }

    /**
     * Returns string describing item
     * 
     * @return string String describes item
     */
    public String toString() {
        String returnString = String.format("Item: %s, Cost: %d", this.name, this.cost);
        return returnString;
    }
}
