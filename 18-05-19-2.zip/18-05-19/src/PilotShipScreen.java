import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;

public class PilotShipScreen {

	private JFrame frame;
	private GameEnvironment game;
	private ArrayList<CrewMember> membersSelected = new ArrayList<>();
	private int numMembersSelected = 0;
	private JLabel lblCrew;
	private JLabel lblCrew_1;
	private JLabel lblCrew_2;
	private JLabel lblCrew_3;
	private JButton btnSelect_1;
	private JButton btnSelect_2;
	private JButton btnSelect_3;
	private JButton btnSelect_4;
	private JComboBox<String> comboBox;
	private JLabel lblCrewMemberSelected;
	private JButton btnPilotShip;
	private JComboBox comboBox_1;
	private JLabel lblWhereTo;
	private JLabel lblCurrentPlanet;
	private JLabel lblPlanet;
	private JLabel lblSelectTwo;

	public PilotShipScreen(GameEnvironment inGame) {
		game = inGame;
		initialize();
		setLabels();
		frame.setVisible(true);
	}
	
	public void closeWindow() {
		frame.dispose();
	}
	
	public void finishedWindow() {
		game.closePilotShipGui(this);
	}
	
	public void pilotShip() {
		if(membersSelected.size() == 2) {
			CrewMember member1 = membersSelected.get(0);
			CrewMember member2 = membersSelected.get(1);
			String planet = comboBox.getSelectedItem().toString();
			
			ArrayList<String> strings = Actions.pilotShip(game.getCrew(), member1, member2, planet);
		
			for(String s : strings) {
				if(s.length() > 0) {
					JOptionPane.showMessageDialog(frame, s, "Pilot Ship",
													JOptionPane.INFORMATION_MESSAGE);
				}
			}
		
			finishedWindow();
		} else {
			JOptionPane.showMessageDialog(frame, "You need to select two crew members to fly the ship", "Pilot Ship",
					JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	public void selectCrewMember(int memberNum) {
		ArrayList<CrewMember> members = game.getCrew().getCrewMemberList();
		
		if(!membersSelected.contains(members.get(memberNum))) {
			if(numMembersSelected < 2) {
				membersSelected.add(members.get(memberNum));
				setLabels();
			} else {
				membersSelected.remove(0);
				membersSelected.add(members.get(memberNum));
				setLabels();
			}
		} else {
			JOptionPane.showMessageDialog(frame, "This crew member has already been selected!", "Pilot Ship",
					JOptionPane.INFORMATION_MESSAGE);
		}
		
		
		//setSelectBtnColours(memberNum);
		//lblCrewMemberSelected.setText("Crew Member Selected: " + memberSelected.getName()); 
	}
	
	public void setLabels() {
		String text = "Crew Members Selected: ";
		for(CrewMember member : membersSelected) {
			text += member.getName() + ", ";
		}
		lblCrewMemberSelected.setText(text);
		
		setCrewLabels();
		
		lblPlanet.setText(game.getCrew().getTheShip().getLocation().getName());
	}
	
	public void setCrewLabels() {
		int crewSize = game.getNumberOfCrew();
		ArrayList<CrewMember> members = game.getCrew().getCrewMemberList();
		
		switch(crewSize) {
			case 2:
				lblCrew.setText(String.format("%s: %s (%d/2)", members.get(0).getName(), members.get(0).getClassType(), members.get(0).getActionsRemaining()));
				lblCrew_1.setText(String.format("%s: %s (%d/2)", members.get(1).getName(), members.get(1).getClassType(), members.get(1).getActionsRemaining()));
				lblCrew_2.setText("");
				frame.remove(btnSelect_3);
				lblCrew_3.setText("");
				frame.remove(btnSelect_4);
				break;
			case 3:
				lblCrew.setText(String.format("%s: %s (%d/2)", members.get(0).getName(), members.get(0).getClassType(), members.get(0).getActionsRemaining()));
				lblCrew_1.setText(String.format("%s: %s (%d/2)", members.get(1).getName(), members.get(1).getClassType(), members.get(1).getActionsRemaining()));
				lblCrew_2.setText(String.format("%s: %s (%d/2)", members.get(2).getName(), members.get(2).getClassType(), members.get(2).getActionsRemaining()));
				lblCrew_3.setText("");
				frame.remove(btnSelect_4);
				break;
			case 4:
				lblCrew.setText(String.format("%s: %s (%d/2)", members.get(0).getName(), members.get(0).getClassType(), members.get(0).getActionsRemaining()));
				lblCrew_1.setText(String.format("%s: %s (%d/2)", members.get(1).getName(), members.get(1).getClassType(), members.get(1).getActionsRemaining()));
				lblCrew_2.setText(String.format("%s: %s (%d/2)", members.get(2).getName(), members.get(2).getClassType(), members.get(2).getActionsRemaining()));
				lblCrew_3.setText(String.format("%s: %s (%d/2)", members.get(3).getName(), members.get(3).getClassType(), members.get(3).getActionsRemaining()));
				break;
			default:
				lblCrew.setText(String.format("%s: %s (%d/2)", members.get(0).getName(), members.get(0).getClassType(), members.get(0).getActionsRemaining()));
				lblCrew_1.setText("");
				frame.remove(btnSelect_2);
				lblCrew_2.setText("");
				lblCrew_3.setText("");
		}
	}
	
	
	
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PilotShipScreen window = new PilotShipScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PilotShipScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 489, 419);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnLeave = new JButton("Leave");
		btnLeave.setBackground(Color.RED);
		btnLeave.setBounds(335, 339, 128, 23);
		btnLeave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow();
			}
		});
		frame.getContentPane().add(btnLeave);
		
		lblCrew = new JLabel("Crew1");
		lblCrew.setFont(new Font("Arial", Font.PLAIN, 12));
		lblCrew.setBounds(20, 89, 219, 49);
		frame.getContentPane().add(lblCrew);
		
		lblCrew_1 = new JLabel("Crew2");
		lblCrew_1.setFont(new Font("Arial", Font.PLAIN, 12));
		lblCrew_1.setBounds(20, 149, 219, 42);
		frame.getContentPane().add(lblCrew_1);
		
		lblCrew_2 = new JLabel("Crew3");
		lblCrew_2.setFont(new Font("Arial", Font.PLAIN, 12));
		lblCrew_2.setBounds(20, 209, 219, 42);
		frame.getContentPane().add(lblCrew_2);
		
		lblCrew_3 = new JLabel("Crew4");
		lblCrew_3.setFont(new Font("Arial", Font.PLAIN, 12));
		lblCrew_3.setBounds(20, 269, 219, 42);
		frame.getContentPane().add(lblCrew_3);
		
		btnSelect_1 = new JButton("Select");
		btnSelect_1.setBackground(Color.LIGHT_GRAY);
		btnSelect_1.setBounds(192, 103, 89, 23);
		btnSelect_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectCrewMember(0);
			}
		});
		frame.getContentPane().add(btnSelect_1);
		
		btnSelect_2 = new JButton("Select");
		btnSelect_2.setBackground(Color.LIGHT_GRAY);
		btnSelect_2.setBounds(192, 163, 89, 23);
		btnSelect_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectCrewMember(1);
			}
		});
		frame.getContentPane().add(btnSelect_2);
		
		btnSelect_3 = new JButton("Select");
		btnSelect_3.setBackground(Color.LIGHT_GRAY);
		btnSelect_3.setBounds(192, 223, 89, 23);
		btnSelect_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectCrewMember(2);
			}
		});
		frame.getContentPane().add(btnSelect_3);
		
		btnSelect_4 = new JButton("Select");
		btnSelect_4.setBackground(Color.LIGHT_GRAY);
		btnSelect_4.setBounds(192, 283, 89, 23);
		btnSelect_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectCrewMember(3);
			}
		});
		frame.getContentPane().add(btnSelect_4);
		
		comboBox = new JComboBox<String>();
		comboBox.setBackground(Color.LIGHT_GRAY);
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Pluto"}));
		comboBox.setBounds(335, 160, 128, 23);
		frame.getContentPane().add(comboBox);
		
		btnPilotShip = new JButton("Pilot Ship");
		btnPilotShip.setBackground(Color.GREEN);
		btnPilotShip.setBounds(335, 194, 128, 60);
		btnPilotShip.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pilotShip();
			}
		});
		frame.getContentPane().add(btnPilotShip);
		
		lblCrewMemberSelected = new JLabel("Crew Members Selected:");
		lblCrewMemberSelected.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 12));
		lblCrewMemberSelected.setBounds(20, 332, 387, 34);
		frame.getContentPane().add(lblCrewMemberSelected);		
		
		lblWhereTo = new JLabel("Where To?");
		lblWhereTo.setFont(new Font("Arial Black", Font.BOLD, 12));
		lblWhereTo.setBounds(335, 132, 128, 31);
		frame.getContentPane().add(lblWhereTo);
		
		lblCurrentPlanet = new JLabel("Current Planet:");
		lblCurrentPlanet.setFont(new Font("Arial Black", Font.ITALIC, 20));
		lblCurrentPlanet.setBounds(10, 24, 185, 31);
		frame.getContentPane().add(lblCurrentPlanet);
		
		lblPlanet = new JLabel("Current Planet:");
		lblPlanet.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblPlanet.setBounds(205, 24, 241, 31);
		frame.getContentPane().add(lblPlanet);
		
		lblSelectTwo = new JLabel("(Select 2)");
		lblSelectTwo.setHorizontalAlignment(SwingConstants.LEFT);
		lblSelectTwo.setFont(new Font("Arial", Font.ITALIC, 10));
		lblSelectTwo.setBounds(20, 349, 155, 34);
		frame.getContentPane().add(lblSelectTwo);
	}
}
