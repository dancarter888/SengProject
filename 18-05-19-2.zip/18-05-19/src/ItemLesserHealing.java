/**
 * This class implements the lesser healing item for the game.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class ItemLesserHealing extends MedicalItem {
	/**
	 * Initializes the class and calls the super of parent class MedicalItem
	 * with the cost, name, and health restored of the item
	 */
    public ItemLesserHealing() {
        super(30, "Lesser Healing", 20);
    }
}
