/**
 * This class implements the spaceghetti item for the game.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class ItemSpaceghetti extends FoodItem {
	/**
	 * Initializes the class and calls the super of parent class FoodItem
	 * with the cost, name, and health restored of the item
	 */
    public ItemSpaceghetti() {
        super(50, "Spaceghetti", 80);
    }
}
