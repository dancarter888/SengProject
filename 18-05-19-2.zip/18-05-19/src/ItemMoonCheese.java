/**
 * This class implements the moon cheese item for the game.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class ItemMoonCheese extends FoodItem {
	/**
	 * Initializes the class and calls the super of parent class FoodItem
	 * with the cost, name, and health restored of the item
	 */
    public ItemMoonCheese() {
        super(20, "Moon Cheese", 25);
    }
}
