/**
 * This class implements the medical item class for the game.
 * It is used to handle the stuff to do with the medical items,
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class MedicalItem implements Item {

	/**
	 * The cost of the item
	 */
    int cost;
    /**
     * The name of the item
     */
    String name;
    /**
     * The amount of health restored by the item
     */
    int healthRestored;

    /**
     * Sets the initial values of the item cost, name, and health restored
     * 
     * @param cost		int cost of the item
     * @param name		String name of the item
     * @param healthRestored	int health restored by item
     */
    public MedicalItem(int cost, String name, int healthRestored) {
        this.cost = cost;
        this.name = name;
        this.healthRestored = healthRestored;
    }

    /**
     * Gets the cost of the item
     */
    @Override
    public int getCost() {
        return cost;
    }

    /**
     * Gets the name of the item
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * Gets the description of the item
     * 
     * @return description String of the description of the item
     */
    @Override
    public String getDescription() {
        String description = "Cures space plague";
        if(name != "Plague Cure") {
            description = String.format("Restores %d health", healthRestored);
        }

        return description;
    }

    /**
     * Uses the item on a member
     * 
     * @param member 	CrewMember the member player wants to use the item on
     * @return text		String of the dialogue from using the item
     */
    @Override
    public String useItem(CrewMember member) {
    	String text = "";
        if(name == "Plague Cure") {
            member.setHasPlague(false);
            text = String.format("%s has been cured", member.getName());
        } else {
            text = member.increaseHealth(healthRestored);
        }
        
        text = String.format("%s item used...\n", name) + text;
        return text;
    }

    /**
     * Returns string describing item
     * 
     * @return string String describes item
     */
    public String toString() {
        String returnString = String.format("Item: %s, Cost: %d", this.name, this.cost);
        return returnString;
    }
}
