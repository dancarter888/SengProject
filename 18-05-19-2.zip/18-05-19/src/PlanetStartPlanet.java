/**
 * This class implements the planet Pluto for the game.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class PlanetStartPlanet extends Planet{
	/**
	 * Initializes the class and calls the super of parent class planet
	 * with the name of the planet
	 */
    PlanetStartPlanet() {
        super("Pluto");
    }
}
