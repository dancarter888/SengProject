/**
 * This class implements the space plague cure item for the game.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class ItemSpacePlagueCure extends MedicalItem {
	/**
	 * Initializes the class and calls the super of parent class MedicalItem
	 * with the cost, name, and health restored of the item
	 */
    public ItemSpacePlagueCure() {
        super(50, "Plague Cure", 0);
    }
}
