/**
 * This class implements the planet Venus for the game.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class PlanetVenus extends Planet{
	/**
	 * Initializes the class and calls the super of parent class planet
	 * with the name of the planet
	 */
	PlanetVenus() {
        super("Venus");
    }
}