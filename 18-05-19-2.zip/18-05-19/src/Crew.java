import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class implements the crew for the game.
 * It is used to handle the crew and everything associated with the crew,
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class Crew {

	/**
	 * The name of the crew
	 */
    private String name;
    /**
     * The size of the crew
     */
    private int crewSize;
    /**
     * The list of the crew members
     */
    private ArrayList<CrewMember> crewMemberList = new ArrayList<>();
    /**
     * The list of items owned by the crew
     */
    private ArrayList<Item> ownedItems = new ArrayList<>();
    /**
     * The list of crew members with actions remaining
     */
    private ArrayList<CrewMember> crewWithActionsRemaining = new ArrayList<>();
    /**
     * The list of crew members with space plague
     */
    private ArrayList<CrewMember> crewWithSpacePlague = new ArrayList<>();
    /**
     * The amount of money the crew has
     */
    private int money = 100;
    /**
     * The Ship
     */
    private Ship theShip;
    /**
     * The number of pieces the crew has found
     */
    private int piecesFound = 0;

    /**
     * Sets the initial values for the crew size, name, and ship name.
     * 
     * @param numberOfCrew	int size of the crew
     * @param name			string the name of the crew
     * @param shipName		string the name of the ship
     */
    public Crew(int numberOfCrew, String name, String shipName) {
        this.name = name;
        this.crewSize = numberOfCrew;
        this.theShip = new Ship(shipName);

        //test item
        ItemApple apple = new ItemApple();
        ownedItems.add(apple);
        ItemSpacePlagueCure cure = new ItemSpacePlagueCure();
        ownedItems.add(cure);
        ItemLesserHealing lesser = new ItemLesserHealing();
        ownedItems.add(lesser);
        ownedItems.add(cure);
        ownedItems.add(lesser);
        ownedItems.add(cure);
        ownedItems.add(apple);
        ownedItems.add(cure);
        ownedItems.add(lesser);
    }

    /**
     * Creates a crew member and adds it to the crew member list.
     * 
     * @param classSelected		int the class wanted for the crew member
     * @param name				string the name of the crew member
     */
    public void createCrewMember(int classSelected, String name) {
    	
    	switch (classSelected) {
        case 1:
            Captain newCaptain = new Captain(name);
            System.out.println("Added Captain " + newCaptain.getName());
            this.crewMemberList.add(newCaptain);
            this.crewWithActionsRemaining.add(newCaptain);
            break;
        case 2:
            Engineer newEngineer = new Engineer(name);
            System.out.println("Added Engineer "  + newEngineer.getName());
            this.crewMemberList.add(newEngineer);
            this.crewWithActionsRemaining.add(newEngineer);
            break;
        default:
            break;
    }
    	
    	
    }

    /**
     * Updates the the list of crew members with actions remaining
     */
    public void updateCrewWithActionsRemaining() {
        ArrayList<CrewMember> actionsRemaining = new ArrayList<>();

        for(CrewMember crewMember : this.crewWithActionsRemaining) {
            if(crewMember.getActionsRemaining() > 0) {
                actionsRemaining.add(crewMember);
            }
        }

        this.crewWithActionsRemaining = actionsRemaining;
    }

    /**
     * Returns whether there are any crew with actions remaining
     * 
     * @return
     */
    public boolean crewWithActions() {
        return this.crewWithActionsRemaining.size() > 0;
    }

    /**
     * Resets the actions remaining for each crew member
     */
    public void resetCrewActions() {
        for(CrewMember member : this.crewMemberList) {
            member.setActionsRemaining(2);
        }
        this.crewWithActionsRemaining = (ArrayList<CrewMember>) this.crewMemberList.clone();
        System.out.println("\nCrew members now have 2 actions remaining\n");
    }

    /**
     * Returns a string of the ship status
     * 
     * @return
     */
    public String getShipStatus() {
        return this.theShip.toString();
    }

    /**
     * Checks that crew has the item the player wants to use and then uses the item.
     * 
     * @param member		CrewMember the member player wants to use the item on
     * @param inItem		String the item the player wants to use
     * @return strings		ArrayList<String> of the dialogue from using the item
     */
    public ArrayList<String> useItem(CrewMember member, String inItem) {
    	ArrayList<String> strings = new ArrayList<>();
    	
        if(this.ownedItems.size() > 0) {
            int indexOfItem = this.chooseItem(inItem);
            if(indexOfItem >=0 ) {
            	Item item = this.ownedItems.get(indexOfItem);
            	strings.add(item.useItem(member));
            	member.performAction();
            	this.ownedItems.remove(item); // could possibly remove in chooseItem()
            } else {
            	strings.add("You do not have that item");
            }
        } else {
            strings.add("You have no items!");
        }
        
        return strings;
    }
    
    /**
     * Returns the index of the item the player wants to use.
     * Returns -1 if player doesn't have item.
     * 
     * @param item	String name of the item
     * @return itemToUse int index of item
     */
    public int chooseItem(String item) {
    	int itemToUse = -1;
    	switch(item) {
    		case "Apple":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemApple) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Moon Cheese":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemMoonCheese) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Spaceghetti":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemSpaceghetti) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Lesser Healing":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemLesserHealing) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Greater Healing":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemGreaterHealing) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		case "Plague Cure":
    			for(Item i : this.ownedItems) {
    				if(i instanceof ItemSpacePlagueCure) {
    					itemToUse = this.ownedItems.indexOf(i);
    				}
    			}
    			break;
    		default:
    			break;
    		
    	}

        return itemToUse;
    }
    
    /**
     * Deals space plague damage to all the crew member that have space plague.
     * 
     * @return strings ArrayList<String> the dialogue of dealing the damage
     */
    public ArrayList<String> dealSpacePlagueDamage() {
        // updates the sapce plague list
    	ArrayList<String> strings = new ArrayList<>();
        this.updateCrewWithSpacePlague(); // where to do this
        // deals the damage for the space plague
        ArrayList<CrewMember> sickMembers = (ArrayList<CrewMember>) this.crewWithSpacePlague.clone();
        for(CrewMember member : sickMembers) {
            strings.add(member.spacePlagueDamage());
            if(member.getHealth() <= 0) {
                strings.add(String.format("%s has died...", member.getName()));
                this.crewMemberList.remove(member);
                this.crewWithSpacePlague.remove(member);
                this.crewSize--;
            }
        }
        
        return strings;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCrewSize() {
        return crewSize;
    }

    public void setCrewSize(int crewSize) {
        this.crewSize = crewSize;
    }

    public ArrayList<CrewMember> getCrewMemberList() {
        return crewMemberList;
    }

    public void setCrewMemberList(ArrayList<CrewMember> crewMemberList) {
        this.crewMemberList = crewMemberList;
    }

    public ArrayList<Item> getOwnedItems() {
        return ownedItems;
    }

    public void addOwnedItems(Item item) {
        this.ownedItems.add(item);
    }

    public void removeOwnedItems(int indexRemoved) {
        this.ownedItems.remove(indexRemoved);
    }

    public void setOwnedItems(ArrayList<Item> ownedItems) {
        this.ownedItems = ownedItems;
    }


    public ArrayList<CrewMember> getCrewWithActionsRemaining() {
        return crewWithActionsRemaining;
    }

    public void setCrewWithActionsRemaining(ArrayList<CrewMember> crewWithActionsRemaining) {
        this.crewWithActionsRemaining = crewWithActionsRemaining;
    }

    public ArrayList<CrewMember> getCrewWithSpacePlague() {
        return crewWithSpacePlague;
    }
    
    /**
     * Updates the list of crew members with space plague.
     */
    public void updateCrewWithSpacePlague() {
        for(CrewMember member : this.crewMemberList) { // not sure if you can use crewwithspaceplague for this
            if(this.crewWithSpacePlague.contains(member) && !member.getHasPlague()) {
                this.crewWithSpacePlague.remove(member);
            }
        }
    }

    /**
     * Adds a member to the list of members with space plague
     * 
     * @param member CrewMember the member to be added to list
     */
    public void addCrewWithSpacePlague(CrewMember member) {
        if(!(this.crewWithSpacePlague.contains(member))) {
            this.crewWithSpacePlague.add(member);
        } else {
            System.out.println("They are allreeady infected");
        }
    }

    public void setCrewWithSpacePlague(ArrayList<CrewMember> crewWithSpacePlague) {
        this.crewWithSpacePlague = crewWithSpacePlague;
    }

    public int getMoney() {
        return money;
    }

    public void addMoney(int amount) {
        this.money += amount;
    }

    public void removeMoney(int amount) {
        this.money -= amount;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public Ship getTheShip() {
        return theShip;
    }

    public void setTheShip(Ship theShip) {
        this.theShip = theShip;
    }

    public int getPiecesFound() {
        return piecesFound;
    }

    public void addPiecesFound() {
        this.piecesFound++;
    }
}
