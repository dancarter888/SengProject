/**
 * This class implements the greater healing item for the game.
 *
 * @author Jakob, Daniel
 * @version something, May 2019
 */
public class ItemGreaterHealing extends MedicalItem {
	/**
	 * Initializes the class and calls the super of parent class MedicalItem
	 * with the cost, name, and health restored of the item
	 */
    public ItemGreaterHealing() {
        super(65, "Greater Healing", 80);
    }
}
